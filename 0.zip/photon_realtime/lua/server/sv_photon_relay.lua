-- sv_photon_relay.lua
-- HTTP relay для пиратского Garry's Mod

if CLIENT then return end

util.AddNetworkString("PhotonDebug")

PHOTON = PHOTON or {}
PHOTON.Players = {}

-- ===== НАСТРОЙКИ =====
PHOTON.Timeout = 3 -- секунд до удаления "мертвого" игрока

print("[Photon] Server relay loaded")

-- ===== ПРИЁМ ДАННЫХ ОТ КЛИЕНТОВ =====
hook.Add("Think", "PhotonCleanup", function()
    local now = CurTime()

    for id, ply in pairs(PHOTON.Players) do
        if now - ply.last > PHOTON.Timeout then
            PHOTON.Players[id] = nil
            print("[Photon] Player timeout:", id)
        end
    end
end)

-- ===== HTTP UPDATE =====
http.Fetch = http.Fetch -- защита от пиратских сборок

concommand.Add("photon_server_debug", function(ply)
    if IsValid(ply) then return end -- только консоль сервера

    PrintTable(PHOTON.Players)
end)

-- ===== ПРИЁМ С CLIENT HTTP =====
gameevent.Listen("player_connect")

hook.Add("PlayerInitialSpawn", "PhotonPlayerSpawn", function(ply)
    print("[Photon] Player joined:", ply:Nick())
end)

hook.Add("PlayerDisconnected", "PhotonPlayerLeave", function(ply)
    local uid = ply:UniqueID()
    if uid then
        PHOTON.Players[util.CRC(uid)] = nil
    end
end)

print("[Photon] Server relay ready")
