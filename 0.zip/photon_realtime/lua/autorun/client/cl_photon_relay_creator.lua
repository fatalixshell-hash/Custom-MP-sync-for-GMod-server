if SERVER then return end

local function CreateRelay()
    local js = [[
const express = require("express");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

const PORT = 8080;
let players = {};

app.post("/update", (req, res) => {
    try {
        const data = JSON.parse(req.body.payload);
        data.last = Date.now();
        players[data.id] = data;
        res.send("ok");
    } catch (e) {
        res.status(400).send("bad");
    }
});

app.get("/state", (req, res) => {
    const now = Date.now();
    for (const id in players) {
        if (now - players[id].last > 3000) {
            delete players[id];
        }
    }
    res.json(players);
});

app.listen(PORT, () => {
    console.log("Photon Relay running on port", PORT);
});
]]

    local bat = [[
@echo off
echo Starting Photon Relay...
cd /d "%~dp0"
npm install express body-parser
node server.js
pause
]]

    file.CreateDir("photon_relay")
    file.Write("photon_relay/server.js", js)
    file.Write("photon_relay/start_relay.bat", bat)

    chat.AddText(Color(0,255,0),
        "[Photon] Relay создан! data/photon_relay/start_relay.bat")
end

concommand.Add("photon_create_relay", CreateRelay)
