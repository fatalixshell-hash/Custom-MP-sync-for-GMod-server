if SERVER then return end

PHOTON = PHOTON or {}

PHOTON.IP   = "127.0.0.1"
PHOTON.PORT = 8080
PHOTON.NICK = "Pirate_" .. math.random(1000,9999)
PHOTON.ID   = "wait"

hook.Add("InitPostEntity", "PhotonInit", function()
    if not IsValid(LocalPlayer()) then return end
    PHOTON.ID = util.CRC(LocalPlayer():UniqueID() or SysTime())
end)

local lastSend = 0

timer.Create("PhotonSend", 0.1, 0, function()
    if not IsValid(LocalPlayer()) then return end
    if SysTime() - lastSend < 0.1 then return end
    lastSend = SysTime()

    local ip = GetConVar("photon_ip"):GetString() or "127.0.0.1"
    local port = GetConVar("photon_port"):GetInt() or 8080

    local pos = LocalPlayer():GetPos()

    http.Post(
        "http://" .. ip .. ":" .. port .. "/update",
        {
            payload = util.TableToJSON({
                id   = PHOTON.ID,
                nick = PHOTON.NICK,
                pos  = {pos.x, pos.y, pos.z},
                hp   = LocalPlayer():Health()
            })
        }
    )
end)

timer.Create("PhotonGet", 0.2, 0, function()
    local ip = GetConVar("photon_ip"):GetString() or "127.0.0.1"
    local port = GetConVar("photon_port"):GetInt() or 8080

    http.Fetch(
        "http://" .. ip .. ":" .. port .. "/state",
        function(body)
            local t = util.JSONToTable(body)
            if not t then return end

            for id, ply in pairs(t) do
                if tostring(id) ~= tostring(PHOTON.ID) then
                    local p = Vector(ply.pos[1], ply.pos[2], ply.pos[3])
                    print("[Photon]", ply.nick, p)
                end
            end
        end
    )
end)

print("[Photon] Client loaded")
