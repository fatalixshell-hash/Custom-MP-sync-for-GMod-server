if SERVER then return end

CreateClientConVar("photon_ip",   "127.0.0.1", true, false)
CreateClientConVar("photon_port", "8080",      true, false)
CreateClientConVar("photon_nick", "Pirate",    true, false)

hook.Add("PopulateToolMenu", "PhotonMenu", function()
    spawnmenu.AddToolMenuOption(
        "Options",
        "Photon",
        "PhotonSettings",
        "Photon Sync",
        "",
        "",
        function(panel)
            panel:ClearControls()
            panel:Help("Photon Sync (Pirate GMod)")

            panel:TextEntry("Relay IP", "photon_ip")
            panel:TextEntry("Relay Port", "photon_port")
            panel:TextEntry("Nick", "photon_nick")

            panel:Button("Применить", "photon_apply")
        end
    )
end)

concommand.Add("photon_apply", function()
    PHOTON.RelayIP   = GetConVar("photon_ip"):GetString()
    PHOTON.RelayPort = GetConVar("photon_port"):GetInt()
    PHOTON.Nick      = GetConVar("photon_nick"):GetString()
    PHOTON.NICK      = (GetConVar("photon_nick"):GetString() or "Pirate") .. "_" .. math.random(1000,9999)

    print("[Photon] Settings applied")
end)
