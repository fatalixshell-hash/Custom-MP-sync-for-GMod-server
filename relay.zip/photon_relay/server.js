const express = require("express");
const Photon = require("photon-realtime");

const app = express();
app.use(express.json());

const PORT = 8080;
const TIMEOUT = 3000;

const appId = "d4e97e1e-65b4-4078-aca0-5ae0718beb63";

let states = {};

const client = new Photon.LoadBalancing.LoadBalancingClient(
    Photon.ConnectionProtocol.Wss,
    appId,
    "1.0"
);

client.onEvent = (code, data) => {
    if (!data || !data.id) return;
    data.last = Date.now();
    states[data.id] = data;
};

client.onStateChange = (state) => {
    if (state === Photon.LoadBalancing.LoadBalancingClient.State.JoinedLobby) {
        console.log("[Photon] Relay ready");
    }
};

client.connectToRegionMaster("eu");

setInterval(() => {
    const now = Date.now();
    for (const id in states) {
        if (now - states[id].last > TIMEOUT) {
            delete states[id];
        }
    }
}, 1000);

app.post("/update", (req, res) => {
    try {
        const data = req.body.payload
            ? JSON.parse(req.body.payload)
            : req.body;

        if (!data.id) return res.sendStatus(400);

        data.last = Date.now();
        states[data.id] = data;

        try {
            client.raiseEvent(1, data);
        } catch (e) {}

        res.send("ok");
    } catch (e) {
        res.sendStatus(400);
    }
});

app.get("/getstate", (req, res) => {
    res.json(states);
});

app.listen(PORT, () =>
    console.log(`[Relay] HTTP + Photon on :${PORT}`)
);
